package com.example.subliminalplayer

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.ExecutionException

class MainActivity : AppCompatActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private lateinit var fileName: TextView
    private lateinit var status: TextView
    private lateinit var volumeLabel: TextView
    private var selectedUri: Uri? = null
    private var selectedName: String = "No audio selected"

    private val audioPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            selectedUri = uri
            selectedName = queryName(uri) ?: "Selected audio"
            fileName.text = selectedName
            status.text = "Audio ready • loop enabled"
            playSelected()
        }
    }

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        fileName = findViewById(R.id.fileName)
        status = findViewById(R.id.status)
        volumeLabel = findViewById(R.id.volumeLabel)

        findViewById<Button>(R.id.importButton).setOnClickListener {
            audioPicker.launch(arrayOf("audio/*"))
        }
        findViewById<Button>(R.id.playButton).setOnClickListener {
            if (selectedUri == null) audioPicker.launch(arrayOf("audio/*")) else playSelected()
        }
        findViewById<Button>(R.id.pauseButton).setOnClickListener {
            controller?.pause()
            status.text = "Paused"
        }
        findViewById<Button>(R.id.stopButton).setOnClickListener {
            controller?.stop()
            controller?.clearMediaItems()
            status.text = "Stopped"
        }

        val slider = findViewById<SeekBar>(R.id.volumeSlider)
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                volumeLabel.text = "Volume $progress%"
                controller?.volume = progress / 100f
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        requestNotificationPermissionIfNeeded()
        connectController()
    }

    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
                controller?.volume = findViewById<SeekBar>(R.id.volumeSlider).progress / 100f
                controller?.repeatMode = Player.REPEAT_MODE_ONE
                if (selectedUri != null && controller?.mediaItemCount == 0) playSelected()
            } catch (e: Exception) {
                status.text = "Unable to connect to audio service"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun playSelected() {
        val uri = selectedUri ?: return
        val c = controller
        if (c == null) {
            status.text = "Starting player…"
            connectController()
            return
        }
        c.setMediaItem(MediaItem.fromUri(uri))
        c.repeatMode = Player.REPEAT_MODE_ONE
        c.prepare()
        c.play()
        status.text = "Playing • repeat on"
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && index >= 0) return cursor.getString(index)
        }
        return uri.lastPathSegment
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}
