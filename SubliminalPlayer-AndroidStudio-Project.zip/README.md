# Subliminal Player (Android native)

A minimal native Android project for looping a user-selected audio file in a foreground media service.

## Features
- Import audio using Android's system file picker (SAF; no broad storage permission).
- Play / pause / stop.
- Loop-one playback.
- Volume slider.
- Foreground media service and persistent notification for background playback.
- Audio focus handling is disabled on the player so Android is allowed to mix it with YouTube. Actual mixing depends on the device, Android version, YouTube, and audio route.
- No network permission, ads, or analytics.

## Build APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.

This is a source project, not a prebuilt APK. A successful APK build requires Android Studio/Gradle and an installed Android SDK.

## Notes
- Android may stop background playback if the user force-stops the app, revokes notifications, or the manufacturer applies aggressive battery restrictions.
- To keep playback going, do not force-stop the app. If needed, set battery usage for the app to Unrestricted in Android settings.
- The app cannot guarantee simultaneous audio on every Android device; some apps/devices may take audio focus or silence other streams.
